({
	doInit : function(component, event, helper) {
		helper.loadOptions(component);
	},
    
    newRace : function(component, event, helper){
        helper.createNewRace(component);
    }
})