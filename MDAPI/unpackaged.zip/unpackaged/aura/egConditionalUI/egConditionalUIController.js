({
	toggle : function(component, event, helper) {
        
		component.set("v.truthy", !component.get("v.truthy"));
	}
})