({
    showDetails : function(component, event, helper) {
        alert("showing Details")
    }
})