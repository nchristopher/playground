({
    handleUpdate : function(component, event, helper){
        helper.updateRace(component);
    }
})