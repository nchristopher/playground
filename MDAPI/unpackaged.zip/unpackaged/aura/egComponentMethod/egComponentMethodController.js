({
    sampleMethodHandler : function(component, event, helper) {
        component.set("v.status", "sampleMethod invoked");
	}
})